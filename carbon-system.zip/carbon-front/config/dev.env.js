"use strict";
const merge = require("webpack-merge");
const prodEnv = require("./prod.env");

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  // BASE_API: '"http://as-demo-dev.wtzhaopin.com:8087/"',
  // BASE_API: '"http://carbonprediction.cern.ac.cn/api/"'
  BASE_API: '"https://carbonprediction.cern.ac.cn/api/"'
  // BASE_API: '"http://223.193.8.235:8883"'
});
