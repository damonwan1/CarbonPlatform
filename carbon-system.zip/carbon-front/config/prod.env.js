"use strict";
module.exports = {
  NODE_ENV: '"production"',
  // BASE_API: '"http://as-demo-dev.wtzhaopin.com:8087/"'
  // BASE_API: '"http://carbonprediction.cern.ac.cn/api/"'
  BASE_API: '"https://carbonprediction.cern.ac.cn/api/"'
};
