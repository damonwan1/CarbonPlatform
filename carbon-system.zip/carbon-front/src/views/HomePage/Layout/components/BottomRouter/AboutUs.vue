<template>
  <h3>这是关于我们页面</h3>
</template>

<script>
export default {
  components: {
  },
  methods: {
    handleOpen(key, keyPath) {
    },
    handleClose(key, keyPath) {
    }
  }
}
</script>
<style>
 .tac{
   height: 400px;
   margin: 50px 0 0 50px;
 }
</style>
