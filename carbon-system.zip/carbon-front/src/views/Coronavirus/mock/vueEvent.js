import Vue from 'vue'
var vueEvent = new Vue();
export default vueEvent;
//emit 与 on使用前提
