package com.as.demo.service;


import com.as.demo.controller.req.LoginReq;
import com.as.demo.entity.ResponseInfo;



public interface IAuthService{

    ResponseInfo login(LoginReq loginReq);


}
