package com.as.demo.utils;

import org.apache.commons.codec.binary.Hex;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/*
 * @Description 将明文密码进行MD5加盐加密
 */
public class SaltMD5Util {

    /*
     * @Description 生成普通的MD5密码
     */
    public static String MD5(String input) {
        MessageDigest md5 = null;
        try {
            // 生成普通的MD5密码
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            return "check jdk";
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        char[] charArray = input.toCharArray();
        byte[] byteArray = new byte[charArray.length];
        for (int i = 0; i < charArray.length; i++)
            byteArray[i] = (byte) charArray[i];
        byte[] md5Bytes = md5.digest(byteArray);
        StringBuffer hexValue = new StringBuffer();
        for (int i = 0; i < md5Bytes.length; i++) {
            int val = ((int) md5Bytes[i]) & 0xff;
            if (val < 16)
                hexValue.append("0");
            hexValue.append(Integer.toHexString(val));
        }
        return hexValue.toString();
    }

    /*
     * @Description 生成盐和加盐后的MD5码，并将盐混入到MD5码中,对MD5密码进行加强
     */
    public static String generateSaltPassword(String password,String salt) {
        //将盐加到明文中，并生成新的MD5码
        password = md5Hex(password + salt);
        //将盐混到新生成的MD5码中，之所以这样做是为了后期更方便的校验明文和秘文，也可以不用这么做，不过要将盐单独存下来，不推荐这种方式
        char[] cs = new char[48];
        for (int i = 0; i < 48; i += 3) {
            cs[i] = password.charAt(i / 3 * 2);
            char c = salt.charAt(i / 3);
            cs[i + 1] = c;
            cs[i + 2] = password.charAt(i / 3 * 2 + 1);
        }
        return new String(cs);
    }



    /*
     * @Description 生成MD5密码
     */
    private static String md5Hex(String src) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] bs = md5.digest(src.getBytes());
            return new String(new Hex().encode(bs));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 生成一个16位的随机数，也就是所谓的盐
     * @return
     */
    public static String getSalt(){
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder(16);
        stringBuilder.append(random.nextInt(99999999)).append(random.nextInt(99999999));
        int len = stringBuilder.length();
        if (len < 16) {
            for (int i = 0; i < 16 - len; i++) {
                stringBuilder.append("0");
            }
        }
        return stringBuilder.toString();
    }


    /*
     * @Description 验证明文和加盐后的MD5码是否匹配
     */
    public static boolean verifySaltPassword(String password,String salt,String md5) {
        //比较二者是否相同
        return generateSaltPassword(password,salt).equals(md5);
    }


    public static void main(String args[]) {
        // 原密码
        String password = "123456";
        System.out.println("明文(原生)密码：" + password);
        // MD5加密后的密码
        String MD5Password = MD5(password);
        System.out.println("普通MD5加密密码：" + MD5Password);
        // 获取加盐后的MD5值
        String salt=getSalt();
        System.out.println(salt);
        String SaltPassword = generateSaltPassword(password,salt);
        System.out.println("加盐后的MD密码：" + SaltPassword);
        System.out.println(verifySaltPassword(password,"3786586643307030","23ae7688cf60052e8116706d14993d93d50517f502136a04"));
    }

}


