package com.as.demo.controller.resp;


import com.as.demo.entity.User;

import java.io.Serializable;

public class LoginResp implements Serializable {
    private String token;

    private User user;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
