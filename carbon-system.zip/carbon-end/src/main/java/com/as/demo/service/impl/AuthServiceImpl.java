package com.as.demo.service.impl;

import com.as.demo.controller.req.LoginReq;
import com.as.demo.controller.resp.LoginResp;
import com.as.demo.entity.ResponseInfo;
import com.as.demo.entity.User;
import com.as.demo.enums.HttpCodeEnum;
import com.as.demo.mapper.UserMapper;
import com.as.demo.service.IAuthService;
import com.as.demo.utils.ResponseInfoUtil;
import com.as.demo.utils.SaltMD5Util;
import com.as.demo.utils.TokenUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;


@Service
public class AuthServiceImpl implements IAuthService {



	@Autowired
	private UserMapper userMapper;


	@Override
	public ResponseInfo login(LoginReq loginReq){
		User findUser = userMapper.getOne(loginReq.getEmail());
		if(null==findUser){
			return ResponseInfoUtil.createResponseInfo(HttpCodeEnum.failed,"用户名不存在");
		}
		//校验密码
		boolean b = SaltMD5Util.verifySaltPassword(loginReq.getPassword(), findUser.getSalt(), findUser.getPassword());
		if(!b){
			return ResponseInfoUtil.createResponseInfo(HttpCodeEnum.failed,"密码错误");
		}
		LoginResp loginResp=new LoginResp();
		loginResp.setUser(findUser);
		String token= TokenUtil.sign(loginReq.getEmail(), LocalDateTime.now());
		loginResp.setToken(token);
		return ResponseInfoUtil.createResponseInfo(HttpCodeEnum.success,"登录成功",loginResp);
	}

}
