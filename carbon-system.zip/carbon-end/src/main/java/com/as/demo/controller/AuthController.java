package com.as.demo.controller;

import com.as.demo.controller.req.LoginReq;
import com.as.demo.entity.ResponseInfo;
import com.as.demo.service.IAuthService;
import com.as.demo.utils.ResponseInfoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@RequestMapping("/auth")
public class AuthController {


	@Autowired
	private IAuthService authService;



	private final Logger logger = LoggerFactory.getLogger(AuthController.class);





	/**
	 * 该平台登录
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseInfo createAuthenticationToken(@RequestBody LoginReq req){
		try {
			Objects.requireNonNull(req.getEmail());
			Objects.requireNonNull(req.getPassword());
			return authService.login(req);
		} catch (Exception e) {
			logger.error("用户登录失败{}", e.getMessage(), e);
			return ResponseInfoUtil.createResult(e);
		}
	}

//	/**
//	 * 该平台注册
//	 * @return
//	 */
//	@RequestMapping(value = "/register", method = RequestMethod.POST)
//	public ResponseInfo register(@RequestBody User user)  {
//		try {
//			Objects.requireNonNull(user.getUsername());
//			Objects.requireNonNull(user.getPassword());
//			Objects.requireNonNull(user.getEmail());
//			return authService.register(user);
//		} catch (Exception e) {
//			logger.error("用户注册失败{}", e.getMessage(), e);
//			return ResponseInfoUtil.createResult(e);
//		}
//	}
}
