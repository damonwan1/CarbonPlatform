package com.as.demo.entity.dto;

import lombok.Data;

@Data
public class ActivityItemMeasureDto {
    private String measureCode;
    private String measureName;
    private String measureUnit;
    private String measureDesc;
    private String measureType;
}
